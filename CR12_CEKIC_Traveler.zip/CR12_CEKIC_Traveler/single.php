<?php get_header(); ?>
<div class="container">
   <div class="row">

  <div class="col-12 col-md-9">
    <div class="container">

        <h1> <?php the_title(); ?></h1>    <!--retrieves blog title-->
      <?php if(have_posts()) : ?> <!--  If there are posts available  -->
       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->
       <h5><?php the_time('F j, Y g:i a'); ?></h5><!--retrieves date blog entry was created-->
       <p> Created by <?php the_author(); ?></p><!--retrieves author of blog entry-->
       
       <?php the_content(); ?><!--retrieves content-->

       <div><?php comments_template();?></div>

       <?php endwhile; ?><!--end the while loop-->
       <?php else :?> <!-- if no posts are found then: -->
       <p>No posts found</p>
       <?php endif; ?> <!-- end if -->
   </div>
  </div>

<div class="d-none d-md-inline col-md-3 border-left"><?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?></div>
</div>
 
</div>
 <?php get_footer(); ?>