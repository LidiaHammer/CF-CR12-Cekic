
<?php get_header(); ?>
<header class="masthead" style="background-image: url('https://images.unsplash.com/photo-1511732351157-1865efcb7b7b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1051&q=80')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h1>It's time to travel</h1>
            <span class="subheading"></span>
          </div>
        </div>
      </div>
    </div>
  </header>
  
    <p class="frontText">Welcome to Mount Everest Agency - Your guide to the best travel locations in 2020</p>


<?php get_footer(); ?>