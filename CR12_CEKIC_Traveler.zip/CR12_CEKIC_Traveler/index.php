<?php get_header(); ?>
   <div class="container mt-3">
     <div class="row">
   <div class=" col-12  col-lg-9">
   <div class="container">
 
         <div class="post-preview">
        <?php if(have_posts()) : ?> <!--  If there are posts available  -->
        <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->
        <?php if(has_post_thumbnail()) : ?>
        <?php the_post_thumbnail('medium'); ?>
         <?php endif; ?> 
          <a href="<?php the_permalink(); ?>">
            <h2 class="post-title">
            <?php the_title(); ?>    
       </a>
            </h2>
            
          </a>
          <p class="post-meta">Posted by
            <?php the_author(); ?> <br>
            <?php the_time('F j, Y g:i a'); ?> </p>
            <p><?php the_excerpt(); ?></p>
       
       <?php endwhile; ?><!--end the while loop-->
<?php else :?> <!-- if no posts are found then: -->

 <p>No posts found</p>  <!-- no posts found displayed -->
<?php endif; ?> <!-- end if -->

</div>
</div>
 </div>
 <div class=" d-none d-md-inline col-lg-3 border-left"><?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?></div>
</div>
</div>
   <?php get_footer(); ?>
   